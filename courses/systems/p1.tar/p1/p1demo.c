#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fct1.h>
#include <unistd.h>
#include <string.h>

int main(int argc, char *argv[])
{
	printf("Hello World");
}
exit(0)

